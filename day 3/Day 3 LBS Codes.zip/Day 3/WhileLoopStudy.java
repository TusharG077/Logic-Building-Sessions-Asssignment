class WhileLoopStudy{
	public static void main(String args[]){
		int count = 10;
		
		while(count <20){
			System.out.println("The Count is " + count);
			count++;
		}
	}
}