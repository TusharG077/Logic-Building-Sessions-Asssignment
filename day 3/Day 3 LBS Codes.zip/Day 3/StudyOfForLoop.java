class StudyOfForLoop{
	public static void main(String args[]){
		for(int i=1; i<11; ++i){
			System.out.println("2 X " + i + " = "+2*i);
		}
	}
}
