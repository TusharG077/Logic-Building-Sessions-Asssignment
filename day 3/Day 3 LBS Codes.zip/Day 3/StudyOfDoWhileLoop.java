class StudyOfDoWhileLoop{
	public static void main(String args[]){
		int input = 5;
		do{
			System.out.println("The value of input is = " + input);
			input ++;
		} while (input < 10);
	}
}