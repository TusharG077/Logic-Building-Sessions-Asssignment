class InfiniteForLoop{
	public static void main(String args[]){
		
		//Condition 01
		for(int i=1;i>=1;i++ ){
			System.out.println( "I am Infinite!!");
		}
		
		//Condition 02
		for(;;){
			System.out.println( "I am Infinite!!");
		}
	}
		
}

//Interview Question: Create infinite for loop.