class NestedForLoopStudyHiCode{
	
	public static void main(String args[]){
		for(int i=0; i<=2; i++){
			for(int j = 0; j <=2; j++){
				System.out.print( "Hi I am i " + i + " and Hi I am j " + j);
			}
			System.out.println( " ");
		}
	}

}
